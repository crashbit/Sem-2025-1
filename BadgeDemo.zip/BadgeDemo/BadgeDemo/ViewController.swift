//
//  ViewController.swift
//  BadgeDemo
//
//  Created by Germán Santos Jaimes on 07/11/24.
//

import UIKit

class ViewController: UIViewController {
    var contador = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addBadge(itemvalue: "0")
    }

    func addBadge(itemvalue: String) {
            let bagButton = BadgeButton()
            bagButton.frame = CGRect(x: 0, y: 0, width: 44, height: 44)
            bagButton.tintColor = UIColor.darkGray
            bagButton.setImage(UIImage(named: "bag.png")?.withRenderingMode(.alwaysTemplate), for: .normal)
            bagButton.badgeEdgeInsets = UIEdgeInsets(top: 18, left: 8, bottom: 0, right: 15)
            bagButton.badge = itemvalue
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: bagButton)
        
            //Experimentación
        
        // Agregamos un Tap Gesture Recognizer
        let tapGestureRecognizer = UITapGestureRecognizer(target: self,
                                                          action: #selector(didTap(_:)))
        tapGestureRecognizer.numberOfTapsRequired = 1
        bagButton.addGestureRecognizer(tapGestureRecognizer)
        }
    
    
    @IBAction func incrementa(_ sender: Any) {
        contador = contador + 1
        self.addBadge(itemvalue: String(contador))
    }
    
    @objc func didTap(_ sender: UITapGestureRecognizer){
            print("Hola tenemos en la bolsa \(String(contador)) productos")
    }
}

